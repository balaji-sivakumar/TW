package com.tw.food.service;

import java.util.ArrayList;
import java.util.List;

import com.tw.food.domain.Address;
import com.tw.food.domain.Item;

import com.tw.food.domain.Order;
import com.tw.food.domain.Shipment;

public class OrderCreateService {
	
	public Order createOrder(String itemId, String zipCode, int orderVolume) {
		
		Order order = new Order();
		List<Item> items = new ArrayList<Item>();
		Item item = new Item();
		List<Shipment> shipments = new ArrayList<Shipment>();
		Shipment shipment = new Shipment();
		
		mockValues(shipment,item,itemId,zipCode);
		items.add(item);
		shipments.add(shipment);
		
		shipment.setItemsRel(items);
		
		order.setOrderId("tw"+System.currentTimeMillis());
		order.setItems(items);
		order.setShipments(shipments);
		
		double shipRate = getShipRateService().computeShipmentPrice(zipCode,orderVolume);
		shipment.setShipRate(shipRate);
		
		double itemTotal = 0d;
		for(Item itemVal: items) {
			itemTotal += itemVal.getPrice();
		}
		double shipmentTotal = 0d;
		for(Shipment shipmentVal: shipments) {
			shipmentTotal += shipmentVal.getShipRate();
		}
		
		double orderTotal = itemTotal + shipmentTotal;
		order.setTotalCost(orderTotal);
		
		
		return order;
	}
	
	
	public void mockValues(Shipment shipment, Item item,String itemId, String zipCode) {
		
		Address address = new Address();
		address.setFirstName("TW");
		address.setLastName("Session");
		address.setCity("Chennai");
		address.setCountry("India");
		
		item.setItemId(itemId);
		item.setPrice(5.0);
		item.setQuantity(1);
		
		address.setZipCode(zipCode);
		shipment.setAddress(address);
	}


	public ShipRateService getShipRateService() {
		return new ShipRateService();
	}

}
