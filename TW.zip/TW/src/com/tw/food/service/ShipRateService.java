package com.tw.food.service;

import java.util.ArrayList;
import java.util.List;

public class ShipRateService {

	public static final int MAX_VOLUME = 50;

	public static final double DEFAULT_RATE = 5.0;
	
	public static final List<String> PEAK_POSTAL_CODE = new ArrayList<String>();

	public double computeShipmentPrice(String zipCode, int orderVolume) {

		double shipRate = 0D;
		
		if(PEAK_POSTAL_CODE.contains(zipCode) && orderVolume > MAX_VOLUME) {
			shipRate = DEFAULT_RATE * 2; //2 X Cost
		}else {
			shipRate = DEFAULT_RATE;
		}
		return shipRate;
	}
	
	static {
		PEAK_POSTAL_CODE.add("600073");
		PEAK_POSTAL_CODE.add("600074");
		PEAK_POSTAL_CODE.add("600075");
	}

}
