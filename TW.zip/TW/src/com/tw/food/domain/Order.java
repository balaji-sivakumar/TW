package com.tw.food.domain;

import java.util.List;

public class Order {

	private String orderId;
	
	private double totalCost;
	
	
	private List<Item> items;
	
	
	private List<Shipment> shipments;


	public List<Shipment> getShipments() {
		return shipments;
	}


	public void setShipments(List<Shipment> shipments) {
		this.shipments = shipments;
	}


	public List<Item> getItems() {
		return items;
	}


	public void setItems(List<Item> items) {
		this.items = items;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public double getTotalCost() {
		return totalCost;
	}


	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}
	
	
}
