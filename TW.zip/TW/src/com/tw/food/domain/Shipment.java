package com.tw.food.domain;

import java.util.List;

public class Shipment {
	
	private List<Item> itemsRel;
	
	private Address address;
	
	private double shipRate;

	public List<Item> getItemsRel() {
		return itemsRel;
	}

	public void setItemsRel(List<Item> itemsRel) {
		this.itemsRel = itemsRel;
	}

	public double getShipRate() {
		return shipRate;
	}

	public void setShipRate(double shipRate) {
		this.shipRate = shipRate;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

}
