package com.tw.food;

import com.tw.food.domain.Item;
import com.tw.food.domain.Order;
import com.tw.food.domain.Shipment;
import com.tw.food.service.OrderCreateService;

public class FoodMain {

	public static void main(String[] args) {
		
		//Inputs
		/** Peak Postal, less then Volume
		String itemId = "X12345";
		String zipCode = "600073";
		int orderVolume = 49;**/
		
		
		/** Peak Postal, greater then Volume
		String itemId = "X12345";
		String zipCode = "600073";
		int orderVolume = 51;**/
		
		/** Peak Postal, greater then Volume**/
		String itemId = "X12345";
		String zipCode = "600074";
		int orderVolume = 150;
		
		
		/** Non Peak Postal Code, Defaut Rate 
		String itemId = "X12345";
		String zipCode = "600045";
		int orderVolume = 49;**/
		
		
		Order order = null;
	
		OrderCreateService createService = new OrderCreateService();
		order = createService.createOrder(itemId, zipCode, orderVolume);
		
		printOrder(order);
		
	}

	private static void printOrder(Order order) {

		System.out.println("Order Id="+order.getOrderId()+
				", First Name="+((Shipment)(order.getShipments().get(0))).getAddress().getFirstName() +
				", Total Cost="+order.getTotalCost() + 
				", Item Id="+ ((Item)order.getItems().get(0)).getItemId() +
				", Item Cost="+ ((Item)order.getItems().get(0)).getPrice() +
		 		", Ship Rate="+ ((Shipment)(order.getShipments().get(0))).getShipRate());
		
	}

}
